
<?php
phpinfo(INFO_MODULES);
?>
