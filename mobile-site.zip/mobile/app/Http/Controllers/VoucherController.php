<?php

namespace App\Http\Controllers;
use Auth;
use App\Models\Currency;
use App\Models\Wallet;
use App\Models\Voucher;
use Illuminate\Http\Request;

class VoucherController extends Controller
{
    
    public function getVouchers(Request $request){
    	$vouchers = Voucher::with('User','Loader')->where('user_id', Auth::user()->id)->orwhere('user_loader', Auth::user()->id)->orderby('created_at', 'desc')->paginate(5);
    	$currencies = Currency::where('id' , '!=', Auth::user()->currentCurrency()->id)->get();
    	return view('vouchers.index')
    	->with('currencies', $currencies)
    	->with('vouchers', $vouchers);
    }
    public function loadVoucher(Request $request){

    	$this->validate($request, [
    		'voucher_code'	=>	'exists:vouchers,voucher_code',
    	]);

    	$voucher = Voucher::where('voucher_code', $request->voucher_code)->where('is_loaded', 0)->first();
	    	if ($voucher == null) {
	    		return back();
	    	}
    	$wallet = Wallet::where('currency_id', $voucher->currency_id)->where('user_id', Auth::user()->id)->first();

    	$wallet->amount = $wallet->amount + $voucher->voucher_value ;

    	$voucher->user_loader = Auth::user()->id;
    	
    	$voucher->is_loaded = 1 ;

    	$voucher->save();

    	$wallet->save();


    	Auth::user()->RecentActivity()->save($voucher->Transactions()->create([
            'user_id' =>  Auth::user()->id,
            'entity_id'   =>  $voucher->id,
            'entity_name' =>  $wallet->currency->name,
            'transaction_state_id'  =>  1, // waiting confirmation
            'money_flow'    => '+',
            'activity_title'    =>  'Voucher Load',
            'currency_id' =>  $voucher->currency_id,
            'currency_symbol' =>  $voucher->currency_symbol,
            'gross' =>  $voucher->voucher_value,
            'fee'   =>  0,
            'net'   =>  $voucher->voucher_value,
            'balance'	=>	$wallet->amount,
        ]));

    	flash('Voucher loaded successfully', 'info');

    	return redirect('/wallet/'.$voucher->currency_id);

    }

    public function createVoucher(Request $request){
    	
    	$this->validate($request, [
    		'voucher_currency'	=>	'exists:currencies,id|numeric',
    		'balance_amount'	=>	'required|numeric'
    	]);

    	
    	$fee = ((setting('money-transfers.mt_percentage_fee')/100)* (double)$request->balance_amount) + setting('money-transfers.mt_fixed_fee');

    	$wallet = Auth::user()->currentWallet() ;

    	if ($wallet->amount < $fee ) {
    		flash(__('You have insufficient funds to send').' <strong>'.$request->balance_amount.__('to').'generate a voucher'.'</strong>', 'danger');
    		return  back();
    	}

    	if ($wallet->amount < (double)$request->balance_amount ){
    		flash(__('You have insufficient funds to send').' <strong>'.$request->balance_amount.__('to').'generate a voucher'.'</strong>', 'danger');
    		return  back();
    	}

    	
    	$voucher_value = $request->balance_amount - $fee ;


    	$voucher = Voucher::create([
    		'user_id'	=>	Auth::user()->id,
    		'voucher_amount'	=>	$request->balance_amount,
    		'voucher_fee'	=>	$fee,
    		'voucher_value'	=>	$voucher_value,
    		'voucher_code'	=>	Auth::user()->id.str_random(4).time().str_random(4),
    		'currency_id'	=>	$wallet->currency->id,
    		'currency_symbol'	=>	$wallet->currency->symbol,
    		'wallet_id'	=>	$wallet->id
    	]);

    	$wallet->amount = $wallet->amount - (double) $request->balance_amount ;

    	$wallet->save();

    	Auth::user()->RecentActivity()->save($voucher->Transactions()->create([
            'user_id' =>  Auth::user()->id,
            'entity_id'   =>  $voucher->id,
            'entity_name' =>  $wallet->currency->name,
            'transaction_state_id'  =>  1, // waiting confirmation
            'money_flow'    => '-',
            'activity_title'    =>  'Voucher Generation',
            'currency_id' =>  $voucher->currency_id,
            'currency_symbol' =>  $voucher->currency_symbol,
            'gross' =>  $voucher->voucher_amount,
            'fee'   =>  $voucher->voucher_fee,
            'net'   =>  $voucher->voucher_value,
            'balance'	=>	$wallet->amount,
        ]));

    	flash('Voucher generated successfully', 'info');

    	return back();
    	//validate the wallet balance 
    }

    public function generateVoucher (Request $request){
        if (Auth::user()->role_id != 1) {
            return back();
        }
        $vouchers = Voucher::with('User','Loader')->where('user_id', Auth::user()->id)->orwhere('user_loader', Auth::user()->id)->orderby('created_at', 'desc')->paginate(5);
        $currencies = Currency::where('id' , '!=', Auth::user()->currentCurrency()->id)->get();
        return view('vouchers.generate')
        ->with('currencies', $currencies)
        ->with('vouchers', $vouchers);

    }

    public function postGenerateVoucher(Request $request){

        $this->validate($request, [
            'voucher_currency'  =>  'exists:currencies,id|numeric',
            'balance_amount'    =>  'required|numeric'
        ]);

        $fee = 0;
        $voucher_value = $request->balance_amount - $fee;
        $wallet = Auth::user()->currentWallet() ;

        $voucher = Voucher::create([
            'user_id'   =>  Auth::user()->id,
            'voucher_amount'    =>  $request->balance_amount,
            'voucher_fee'   =>  $fee,
            'voucher_value' =>  $voucher_value,
            'voucher_code'  =>  Auth::user()->id.str_random(4).time().str_random(4),
            'currency_id'   =>  $wallet->currency->id,
            'currency_symbol'   =>  $wallet->currency->symbol,
            'wallet_id' =>  $wallet->id
        ]);


        Auth::user()->RecentActivity()->save($voucher->Transactions()->create([
            'user_id' =>  Auth::user()->id,
            'entity_id'   =>  $voucher->id,
            'entity_name' =>  $wallet->currency->name,
            'transaction_state_id'  =>  1, // waiting confirmation
            'money_flow'    => '↑',
            'activity_title'    =>  'Added Voucher to system',
            'currency_id' =>  $voucher->currency_id,
            'currency_symbol' =>  $voucher->currency_symbol,
            'gross' =>  $voucher->voucher_amount,
            'fee'   =>  $voucher->voucher_fee,
            'net'   =>  $voucher->voucher_value,
            'balance'   =>  $wallet->amount,
        ]));

        flash('Voucher generated successfully', 'info');

        return back();


    }

    public function buyvoucher(Request $request){
        $user = Auth::user();
        $user->currency_id = 1;
        $user->save();
        return view('vouchers.buy');
    }
}
