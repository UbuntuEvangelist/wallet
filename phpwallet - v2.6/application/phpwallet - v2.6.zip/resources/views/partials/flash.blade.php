<div class="container">
    @include('flash')
</div>