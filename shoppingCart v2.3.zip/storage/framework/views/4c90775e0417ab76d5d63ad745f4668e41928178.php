

<?php $__env->startSection('content'); ?>
        <div class="row-cleardix">
            <div class="col-lg-12 pl-0 pr-0">
                <div class="card">
                    <div class="header">
                        <h2><strong>Single</strong> Invoice</h2>
                        <ul class="header-dropdown">
                     
                        </ul>
                    </div>
                    <div class="body">
                        <h3 class="m-b-0">Invoice Details : <strong class="text-primary">#<?php echo e($invoice->id); ?></strong></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane in active" id="details" aria-expanded="true">
                <div class="card" id="details">
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-md-6 col-sm-6">
                                <address>
                                    <strong>ThemeMakker Inc.</strong><br>
                                    795 Folsom Ave, Suite 546<br>
                                    San Francisco, CA 54656<br>
                                    <abbr title="Phone">P:</abbr> (123) 456-34636
                                </address>
                            </div>
                            <div class="col-md-6 col-sm-6 text-right">
                                <p class="m-b-0"><strong>Order Date: </strong> <?php echo e($invoice->created_at); ?></p>
                                <p class="m-b-0"><strong>Order Status: </strong> <span class="badge badge-warning m-b-0"><?php echo e(($invoice->is_paid)? 'paid' : 'waiting payment'); ?></span></p>
                                <p><strong>Order ID: </strong> #<?php echo e($invoice->id); ?></p>
                            </div>
                        </div>
                        <div class="row clearfix">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            
                                            <tr>
                                                <th>#</th>                                                        
                                                <th>Item</th>
                                                <th class="hidden-sm-down">Description</th>
                                                <th>Quantity</th>
                                                <th class="hidden-sm-down">Unit Cost</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $invoice->json_data->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td> <?php echo e($loop->index); ?> </td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td class=""> <?php echo e($item->description); ?> </td>
                                                <td class=""> <?php echo e($item->qty); ?> </td>
                                                 <td class=""> <?php echo e(setting('phpwallet.merchant_currency_symbol')); ?><?php echo e($item->price); ?> </td>
                                                <td class=""> <?php echo e(setting('phpwallet.merchant_currency_symbol')); ?><?php echo e(($item->price * $item->qty)); ?> </td>
                                            </tr>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row clearfix">
                            <div class="col-md-6">
                                <h5>Note</h5>
                                <p>Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem plugg dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.</p>
                            </div>
                            <div class="col-md-6 text-right">
                                <p class="m-b-0"><b>Sub-total:</b> $<?php echo e($invoice->json_data->total); ?></p>
                                <p class="m-b-0">Shipping: 0</p>                                        
                                <h3 class="m-b-0 m-t-10"><?php echo e(setting('phpwallet.merchant_currency')); ?> <?php echo e($invoice->json_data->total); ?></h3>
                            </div>                                    
                            <div class="hidden-print col-md-12 text-right">
                                <hr>
                                <button class="btn btn-warning btn-icon  btn-icon-mini btn-round"><i class="zmdi zmdi-print"></i></button>
                                <button class="btn btn-primary btn-round">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>