<nav class="top_navbar">
    <div class="container">
        
        <div class="row clearfix">
            <div class="col-12">
                <div class="navbar-logo">
                    <a href="javascript:void(0);" class="bars"></a>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('assets/images/logo.svg')); ?>" width="30" alt="InfiniO"> 
                        <span class="m-l-10"><?php echo e(setting('site.title')); ?></span>
                    </a>
                </div>
                <?php if(auth()->guard()->check()): ?>
                <ul class="nav navbar-nav">
                    <li class="dropdown profile "><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                        <?php if(!Cart::session(Auth::user()->id)->isEmpty()): ?>
                            <i class="icon-basket-loaded"></i>
                            <span class="label-count"> <?php echo e(Cart::getContent()->count()); ?> </span>
                        <?php else: ?>
                            <i class="icon-basket"></i>
                            <span class="label-count">0</span>
                        <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">Your Cart</li>
                            <li class="body">
                                <ul class="menu tasks list-unstyled">
                                <?php if(!Cart::session(Auth::user()->id)->isEmpty()): ?>    
                                    <?php $__currentLoopData = Cart::session(Auth::user()->id)->getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(url('/')); ?>/remove/<?php echo e($cartItem->id); ?>">
                                                <span class="text-muted"><span class="text-primary"><?php echo e(str_limit($cartItem->name, 20,  '...')); ?></span><span class="float-right">Qty:  <?php echo e($cartItem->quantity); ?></span></span>
                                                <span class="clearfix"></span>
                                                 <span class="text-muted"> <span class="float-right">Price: <?php echo e(setting('phpwallet.merchant_currency_symbol')); ?><?php echo e($cartItem->price); ?></span></span>
                                                 <span class="clearfix"></span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>                         
                                </ul>
                            </li>
                            <li class="footer"><a href="<?php echo e(url('/')); ?>/checkout"><span class="text-muted">Checkout<span class="float-right"><strong> <?php echo e(Cart::session(Auth::user()->id)->getTotal()); ?> <?php echo e(setting('phpwallet.merchant_currency_symbol')); ?></strong></span></span><span class="clearfix"></span></a></li>
                        </ul>
                    </li>
                    <li class="dropdown profile">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <img class="rounded-circle" src="<?php echo e(url('/')); ?>/storage/users/default.png" alt="User">
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="user-info">
                                    <h6 class="user-name m-b-0"><?php echo e(Auth::user()->name); ?></h6>
                                    
                                    <hr>
                                </div>
                            </li>                            
                            <li><a href="profile.html"><i class="icon-user m-r-10"></i> <span>My Profile</span> </a></li>
                            <li><a href="<?php echo e(url('/')); ?>/orders"><i class="icon-notebook m-r-10"></i><span>My Orders</span> </a></li>                            
                            <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="icon-power m-r-10"></i><span>Sign Out</span></a><form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form></li>
                        </ul>
                    </li>
                    <li><a href="javascript:void(0);" class="js-right-sidebar"><i class="icon-equalizer"></i></a></li>
                </ul>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <ul class="nav navbar-nav">
                        <li class="dropdown profile "><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button"><i class="icon-basket"></i>
                       
                            <span class="label-count">0</span>
                     
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">Your Cart</li>
                            <li class="body">
                                <ul class="menu tasks list-unstyled">
                                                     
                                </ul>
                            </li>
                            <li class="footer"><a href="#"><span class="text-muted">Checkout<span class="float-right"><strong> 0 <?php echo e(setting('phpwallet.merchant_currency_symbol')); ?></strong></span></span><span class="clearfix"></span></a></li>
                        </ul>
                    </li>
                        <li class="dropdown profile">
                            <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                                <img class="rounded-circle" src="<?php echo e(url('/')); ?>/storage/users/default.png" alt="User">
                            </a>
                             <ul class="dropdown-menu">
                                <li>
                                    <div class="user-info">
                                        <h6 class="user-name m-b-0">Guest</h6>
                                        
                                        <hr>
                                    </div>
                                </li>                            
                                <li><a href="<?php echo e(url('/')); ?>/login"><i class="icon-user m-r-10"></i> <span><?php echo e(__('Login')); ?></span> </a></li>
                                 <li><a href="<?php echo e(url('/')); ?>/register"><i class="icon-user m-r-10"></i> <span><?php echo e(__('Register')); ?></span> </a></li>
                            </ul>

                        </li>
                         <li><a href="javascript:void(0);" class="js-right-sidebar"><i class="icon-equalizer"></i></a></li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>        
    </div>
</nav>