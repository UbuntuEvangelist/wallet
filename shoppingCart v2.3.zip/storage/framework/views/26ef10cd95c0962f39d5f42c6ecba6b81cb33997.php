

<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="body">
                <div class="row">
                    <div class="preview col-lg-4 col-md-12">
                        <div class="preview-pic tab-content">
                            <div class="tab-pane active show" id="product_1"><img src="<?php echo e($product->thumbnailurl); ?>" class="img-fluid"></div>
                            <?php if( !is_null($product->preview1_url) ): ?>
                            <div class="tab-pane" id="product_2"><img src="<?php echo e($product->preview1_url); ?>" class="img-fluid"></div>
                            <?php endif; ?>
                            <?php if( !is_null($product->preview2_url) ): ?>
                            <div class="tab-pane" id="product_3"><img src="<?php echo e($product->preview2_url); ?>" class="img-fluid"></div>
                            <?php endif; ?>
                            <?php if( !is_null($product->preview3_url) ): ?>
                            <div class="tab-pane" id="product_4"><img src="<?php echo e($product->preview3_url); ?>" class="img-fluid"></div>
                            <?php endif; ?>
                            <?php if( !is_null($product->preview4_url) ): ?>
                            <div class="tab-pane " id="product_5"><img src="<?php echo e($product->preview4_url); ?>" class="img-fluid"></div>
                            <?php endif; ?>
                        </div>
                        <ul class="preview-thumbnail nav nav-tabs">
                            <li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#product_1"><img src="<?php echo e($product->thumbnailurl); ?>"></a></li>
                            <?php if( !is_null($product->preview1_url) ): ?>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#product_2"><img src="<?php echo e($product->preview1_url); ?>"></a></li>
                            <?php endif; ?>
                            <?php if( !is_null($product->preview2_url) ): ?>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#product_3"><img src="<?php echo e($product->preview2_url); ?>"></a></li>
                            <?php endif; ?>
                            <?php if( !is_null($product->preview3_url) ): ?>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#product_4"><img src="<?php echo e($product->preview3_url); ?>"></a></li>
                            <?php endif; ?>
                            <?php if( !is_null($product->preview4_url) ): ?>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#product_5"><img src="<?php echo e($product->preview4_url); ?>"></a></li>
                            <?php endif; ?>                                    
                        </ul>                
                    </div>
                    <div class="details col-lg-8 col-md-12">
                        <h3 class="product-title m-b-0"><?php echo e($product->title); ?></h3>
                        <h4 class="price m-t-0">Current Price: <span class="col-amber"><?php echo e(setting('phpwallet.merchant_currency_symbol')); ?><?php echo e($product->price); ?></span></h4>
                        
                        <hr>
                        <p class="product-description"><?php echo $product->description; ?></p>
                        
                        <hr>
                        <div class="action">
                          <form class="d-flex justify-content-left" method="post" action="<?php echo e(url('/')); ?>/addtocart">
                            <input type="number" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                              <input class="btn btn-primary btn-round waves-effect" value="add to cart" type="submit">
                              
                          </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>

  

   <!--Grid row-->
      <div class="row d-flex justify-content-center wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 text-center">

          <h4 class="my-4 h4">Related Products</h4>

          
        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
      <!--Grid row-->
      <div class="row wow fadeIn">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php

            $thumbnail = 'thumbnails/'.$product->thumbnail ;
          
          ?>
            
             <div class="col-lg-3 col-md-4 col-sm-12">
                <div class="card product_item">
                    <div class="body">
                        <div class="cp_img">
                            <img src="<?php echo e($product->thumbnailurl); ?>" alt="Product" class="img-fluid">
                            <div class="hover">

                                <a href="<?php echo e(url('/')); ?>/item/<?php echo e($product->title); ?>/<?php echo e($product->id); ?>" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            </div>
                        </div>
                        <div class="product_details">
                            <h5><a href="<?php echo e(url('/')); ?>/item/<?php echo e($product->title); ?>/<?php echo e($product->id); ?>"><?php echo e(str_limit($product->title, 20,  '...')); ?></a></h5>
                            <ul class="product_price list-unstyled">
                                <?php if(( $product->old_price > 0 ) and ($product->old_price != $product->price)): ?>
                                <li class="old_price" style="text-decoration: line-through;"><?php echo e(setting('phpwallet.merchant_currency_symbol')); ?> <?php echo e(\App\Helpers\Money::instance()->value($product->old_price, '')); ?></li>
                                <?php endif; ?>
                                <li class="new_price text-success"><?php echo e(setting('phpwallet.merchant_currency_symbol')); ?> <?php echo e(\App\Helpers\Money::instance()->value($product->price, '')); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>                
            </div>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <!--Grid row-->

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>