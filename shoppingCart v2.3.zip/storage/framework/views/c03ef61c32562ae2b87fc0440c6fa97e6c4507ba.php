<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-12 ">
                <div class="card-plain">
                    <div class="header">
                        <h5><?php echo e(__('Sign Up')); ?></h5>
                    </div>
                    <form class="form" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>                        
                        <div class="input-group">
                            <input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Enter User Name')); ?>" required autofocus>
                            <span class="input-group-addon"><i class="zmdi zmdi-account-circle"></i></span>
                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="input-group">
                            <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Enter Email')); ?>" required >
                            <span class="input-group-addon"><i class="zmdi zmdi-email"></i></span>
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="input-group">
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>"  required>
                            <span class="input-group-addon"><i class="zmdi zmdi-lock"></i></span>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="input-group">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="<?php echo e(__('Repeat Password')); ?>" required>
                            <span class="input-group-addon"><i class="zmdi zmdi-lock"></i></span>
                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                    <div class="footer">
                        <input type="submit" value="<?php echo e(__('SIGN UP')); ?>" class="btn btn-primary btn-round btn-block">
                    </div>
                    </form>
                    <a class="link" href="<?php echo e(url('/')); ?>/login"><?php echo e(__('You already have a membership?')); ?></a>
                </div>
            </div>>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>