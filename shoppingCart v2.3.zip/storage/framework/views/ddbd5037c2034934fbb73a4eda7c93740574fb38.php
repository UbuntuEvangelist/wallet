

<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="header">
                <h2> <strong>Orders</strong></h2>
               
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>FIRST NAME</th>
                                <th>LAST NAME</th>
                                <th>USERNAME</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?> </td>
                        <td class=""> <?php echo e($invoice->id); ?>  </td>
                        <td class=""> <?php echo e($invoice->updated_at->diffForHumans()); ?>  </td>

                        <td class=""> <?php echo e(($invoice->is_paid)? 'paid' : 'waiting payment'); ?>  </td>
                        <td class="text-right"><a class="btn btn-primary" href="<?php echo e(url('/')); ?>/invoice/<?php echo e($invoice->id); ?>">View order invoice</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div>
                    <h1>You don't have orders.</h1>
                </div>
                <?php endif; ?>
                           
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="footer">
                <hr>
                <?php echo e($invoices->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>