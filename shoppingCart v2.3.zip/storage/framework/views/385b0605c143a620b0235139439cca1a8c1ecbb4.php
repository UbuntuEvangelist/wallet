<?php $__env->startSection('content'); ?>

    <div class="row clearfix">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php

            $thumbnail = 'thumbnails/'.$product->thumbnail ;
          
          ?>
            <div class="col-lg-3 col-md-4 col-sm-12">
                <div class="card product_item">
                    <div class="body">
                        <div class="cp_img">
                            <img src="<?php echo e($product->thumbnailurl); ?>" alt="Product" class="img-fluid">
                            <div class="hover">

                                <a href="<?php echo e(url('/')); ?>/item/<?php echo e($product->title); ?>/<?php echo e($product->id); ?>" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            </div>
                        </div>
                        <div class="product_details">
                            <h5><a href="<?php echo e(url('/')); ?>/item/<?php echo e($product->title); ?>/<?php echo e($product->id); ?>"><?php echo e(str_limit($product->title, 20,  '...')); ?></a></h5>
                            <ul class="product_price list-unstyled">
                                <?php if(( $product->old_price > 0 ) and ($product->old_price != $product->price)): ?>
                                <li class="old_price text-primary" style="text-decoration: line-through;"><?php echo e(setting('phpwallet.merchant_currency_symbol')); ?> <?php echo e(\App\Helpers\Money::instance()->value($product->old_price, '')); ?></li>
                                <?php endif; ?>
                                <li class="new_price text-success"><?php echo e(setting('phpwallet.merchant_currency_symbol')); ?> <?php echo e(\App\Helpers\Money::instance()->value($product->price, '')); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>                
            </div>
           
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!--Pagination-->
    <?php if($products->lastPage() > 1): ?>
    <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="body block-header">
                        <div class="row">
                            <div class="col">
                                <?php echo e($products->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

       

       
      

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>