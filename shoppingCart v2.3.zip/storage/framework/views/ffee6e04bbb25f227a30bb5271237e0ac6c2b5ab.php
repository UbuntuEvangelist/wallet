<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-12">
                <div class="card-plain">
                    <div class="header">
                        <h5><?php echo e(__('Log in')); ?></h5>
                    </div>
                    <form class="form" method="POST" action="<?php echo e(route('login')); ?>">
                         <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input  id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email')); ?>" required autofocus>
                            <span class="input-group-addon"><i class="zmdi zmdi-account-circle"></i></span>
                            <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="input-group">
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
                            <span class="input-group-addon"><i class="zmdi zmdi-lock"></i></span>
                             <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div> 
                        <div class="checkbox float-left">
                            <input id="terms" type="checkbox">
                            <label for="terms"><?php echo e(__('Remember me')); ?></label>
                        </div>                         
                        <div class="clearfix"></div>
                        <div class="footer">
                            <input type="submit" class="btn btn-primary btn-round btn-block" value="<?php echo e(__('SIGN IN')); ?>">
                            <a href="<?php echo e(url('/')); ?>/register" class="btn btn-primary btn-simple btn-round btn-block"><?php echo e(__('SIGN UP')); ?></a>
                        </div>
                     </form>
                    <a href="<?php echo e(route('password.request')); ?>" class="link"><?php echo e(__('Forgot Your Password?')); ?></a>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>