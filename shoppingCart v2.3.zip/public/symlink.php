<?php
symlink('/home/scrizrea/shoppingcart.scriptdemo.website/storage/app/public', '/home/scrizrea/shoppingcart.scriptdemo.website/public/storage');
?>