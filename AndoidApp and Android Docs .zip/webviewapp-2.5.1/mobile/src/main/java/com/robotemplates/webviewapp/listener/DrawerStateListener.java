package com.robotemplates.webviewapp.listener;

public interface DrawerStateListener {
	boolean isDrawerOpen();
	void onBackButtonPressed();
}
