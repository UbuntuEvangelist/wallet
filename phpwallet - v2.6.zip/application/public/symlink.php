<?php
symlink('/home/scrizrea/dev.scriptdemo.website/storage/app/public', '/home/scrizrea/dev.scriptdemo.website/public/storage');
?>