<?php
symlink('/home/scrizrea/public_html/application/storage/app/public', '/home/scrizrea/public_html/storage');
?>